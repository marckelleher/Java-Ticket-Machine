/**
 * TicketMachine models a naive ticket machine that issues
 * flat-fare tickets.
 * The price of a ticket is specified via the constructor.
 * It is a naive machine in the sense that it trusts its users
 * to insert enough money before trying to print a ticket.
 * It also assumes that users enter sensible amounts.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2011.07.31
 * 
 * Modifications:
 * Author: Marc Kelleher  7/13/15
 * Added getTotal method from exercise 2.26 of Objects First with Java.
 * Modified setPrice method from exercise 2.32.
 * Added prompt method from exercise 2.37.
 * Added showPrice method from exercise 2.41.
 * Modified TicketMachine constructor from exercise 2.43.
 * Modified TicketMachine constructor again, from exercise 2.44.
 * Added a constructor to TicketMachine from exercise 2.44.
 * Added empty method from exercise 2.45.
 */
public class TicketMachine
{
    // The price of a ticket from this machine.
    private int price;
    // The amount of money entered by a customer so far.
    private int balance;
    // The total amount of money collected by this machine.
    private int total;

    /**
     * Create a machine that issues tickets of the given price.
     * Note that the price must be greater than zero, and there
     * are no checks to ensure this.
     * Ex. 2.43
     * Modifications:
     * Marc Kelleher 7/12/15
     * I changed the parameters to none and the default value of price to 1000.
     * Marc Kelleher 7/13/15
     * I changed the parameters to accept a parameter of the ticket cost as cost.
     */
    public TicketMachine(int cost)
    {
        price = cost;
        balance = 0;
        total = 0;
    }
    
    /**
     * Ex. 2.44
     * Create a machine that issues tickets at the price of 1300.
     */
    public TicketMachine()
    {
        price = 1300;
        balance = 0;
        total = 0;
    }

    /**
     * Return the price of a ticket.
     */
    public int getPrice()
    {
        return price;
    }

    /**
     * Return the amount of money already inserted for the
     * next ticket.
     */
    public int getBalance()
    {
        return balance;
    }

    /**
     * Receive an amount of money from a customer.
     */
    public void insertMoney(int amount)
    {
        balance = balance + amount;
    }

    /**
     * Print a ticket.
     * Update the total collected and
     * reduce the balance to zero.
     */
    public void printTicket()
    {
        // Simulate the printing of a ticket.
        System.out.println("##################");
        System.out.println("# The BlueJ Line");
        System.out.println("# Ticket");
        System.out.println("# " + price + " cents.");
        System.out.println("##################");
        System.out.println();

        // Update the total collected with the balance.
        total = total + balance;
        // Clear the balance.
        balance = 0;
    }
    
    /**
     * Ex. 2.26
     * Name: getTotal
     * Description: return the total field
     */
    public int getTotal()
    {
        // Return the value of the total field.
        return total;
    }
    /**
     * Ex. 2.32
     * Name: setPrice
     * Description: Assign the value of price
     */
    public void setPrice(int cost)
    {
        // Assigns the value of the cost parameter to the price field.
        cost = price;
    }
    /**
     * Ex. 2.37
     * Name: prompt
     * Description: Print a message asking for the right amount of money
     */
    public void prompt()
    {
        // Prints a single line asking for the correct amount of money.
        System.out.println("Please insert the correct amount of money.");
    }
    /**
     * Ex. 2.41
     * Name: showPrice
     * Description: Print a message of the price of a ticket
     */
    public void showPrice()
    {
        // Prints a single line showing the price of the ticket.
        System.out.println("The price of a ticket is " + price + " cents.");
    }
    /**
     * Ex. 2.45
     * Name: empty
     * Description: sets the total field to 0
     */
    public void empty()
    {
        // Sets the value of the total field to 0.
        total = 0;
    }
}
